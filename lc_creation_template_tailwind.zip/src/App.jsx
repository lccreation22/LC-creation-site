import { useState } from "react";
import { Check, Leaf, Phone, Mail, Wrench, Ruler, Truck } from "lucide-react";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

export default function SitePaysagiste() {
  const [sending, setSending] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSending(true);
    await new Promise((r) => setTimeout(r, 1000));
    alert("Merci ! Nous vous recontactons très vite.");
    setSending(false);
    e.target.reset();
  };

  const projects = [
    { img: "/photos/IMG_20250722_075234.jpg", title: "Pavage & aménagement technique" },
    { img: "/photos/FB_IMG_1750392955462.jpg", title: "Cour & plantations" },
    { img: "/photos/IMG_20241101_121859868_MP~2.jpg", title: "Terrasse moderne" },
    { img: "/photos/IMG_20250420_082002156_HDR.jpg", title: "Chemin en pas japonais" },
    { img: "/photos/IMG_20250611_094747.jpg", title: "Allée pavée" },
    { img: "/photos/IMG_20250820_092216.jpg", title: "Entretien & taille" },
  ];

  return (
    <div className="min-h-screen bg-white text-gray-900">
      {/* Top bar */}
      <header className="sticky top-0 z-40 border-b bg-white/80 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src="/assets/logo-amenagement.png" alt="LC Creation" className="w-10 h-10 object-contain rounded-lg bg-white ring-1 ring-gray-200"/>
            <div>
              <p className="font-semibold leading-none">LC Creation SRL</p>
              <p className="text-xs text-gray-500">Aménagements extérieurs • Rénovation</p>
            </div>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#realisations" className="hover:text-emerald-700">Réalisations</a>
            <a href="#contact" className="hover:text-emerald-700">Contact</a>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 py-16">
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight">
            Des extérieurs <span className="text-emerald-600">durables</span> et bien pensés
          </h1>
          <p className="mt-5 text-lg text-gray-700 max-w-2xl">
            Création de jardins, terrasses, allées et entretien. Une équipe réactive, un seul interlocuteur, des finitions impeccables.
          </p>
          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <a href="#contact" className="inline-block bg-emerald-600 text-white px-5 py-3 rounded-2xl">Obtenir un devis</a>
            <a href="#realisations" className="inline-block bg-gray-100 text-gray-900 px-5 py-3 rounded-2xl">Voir nos réalisations</a>
          </div>
          <div className="mt-6 flex items-center gap-6 text-sm text-gray-600">
            <span className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600"/>Devis sous 48h</span>
            <span className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600"/>Assuré & garanti</span>
            <span className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600"/>Déplacements régionaux</span>
          </div>
        </div>
      </section>

      {/* Réalisations */}
      <section id="realisations" className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold">Réalisations récentes</h2>
          <p className="mt-2 text-gray-600">Un aperçu de chantiers livrés cette saison.</p>
          <div className="mt-8">
            <Carousel autoPlay infiniteLoop showThumbs={false} showStatus={false} interval={4000}>
              {projects.map((p, i) => (
                <div key={i} className="relative">
                  <img src={p.img} alt={p.title} className="object-cover h-[500px] w-full rounded-2xl"/>
                  <div className="absolute bottom-3 left-3 bg-white/70 text-gray-800 px-3 py-1 rounded-lg text-sm shadow">
                    {p.title}
                  </div>
                  <img src="/assets/logo-amenagement.png" alt="Logo filigrane" className="absolute bottom-3 right-3 w-12 h-12 opacity-60"/>
                </div>
              ))}
            </Carousel>
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16 bg-emerald-50/40">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold">Contact & devis</h2>
            <p className="mt-2 text-gray-600">Décrivez brièvement votre besoin, on vous rappelle rapidement.</p>
            <div className="mt-6 space-y-3 text-gray-700">
              <p className="flex items-center gap-2"><Phone className="w-4 h-4 text-emerald-700"/> 0474/69.38.00</p>
              <p className="flex items-center gap-2"><Mail className="w-4 h-4 text-emerald-700"/> lecocqcedric@outlook.be</p>
            </div>
          </div>
          <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 ring-1 ring-gray-200 space-y-4">
            <input name="nom" placeholder="Nom" required className="w-full border rounded-lg px-3 py-2"/>
            <input name="email" type="email" placeholder="Email" required className="w-full border rounded-lg px-3 py-2"/>
            <input name="tel" placeholder="Téléphone" className="w-full border rounded-lg px-3 py-2"/>
            <textarea name="message" rows="5" placeholder="Votre projet (surface, idées, délais)" required className="w-full border rounded-lg px-3 py-2"></textarea>
            <button type="submit" className="w-full bg-emerald-600 text-white px-4 py-2 rounded-2xl">{sending ? "Envoi..." : "Envoyer ma demande"}</button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 border-t">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-6 text-sm">
            <div>
              <p className="font-semibold">LC Creation SRL</p>
              <p className="text-gray-600 mt-2">TVA BE 1015.582.575</p>
            </div>
            <div>
              <p className="font-semibold">Zones</p>
              <ul className="mt-2 space-y-1 text-gray-600">
                <li>Bruxelles</li>
                <li>Brabant Wallon</li>
                <li>Brabant Flamand</li>
              </ul>
            </div>
            <div>
              <p className="font-semibold">Contact</p>
              <ul className="mt-2 space-y-1 text-gray-600">
                <li>0474/69.38.00</li>
                <li>lecocqcedric@outlook.be</li>
              </ul>
            </div>
            <div>
              <img src="/assets/logo-amenagement.png" alt="Aménagements" className="h-10 inline-block mr-4 bg-white rounded-md p-1 ring-1 ring-gray-200"/>
              <img src="/assets/logo-renovation.png" alt="Rénovation" className="h-10 inline-block bg-white rounded-md p-1 ring-1 ring-gray-200"/>
            </div>
          </div>
          <p className="mt-8 text-xs text-gray-500">© {new Date().getFullYear()} — Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
}